import openpyxl as xl
from openpyxl.chart import BarChart3D, Reference

# load my file xlsx in variable wb
wb = xl.load_workbook('trans2.xlsx')

# locate on my sheet Sheet1
sheet = wb['Sheet1']
for row in range(2, sheet.max_row+1): #iterating in the rows from 2 to  4 col 3
    cell = sheet.cell(row, 3)         # show python the iterable cell
    new_price = cell.value * 0.9      # in a var put the wished expression
    cell_new = sheet.cell(row, 4)     # show python the new rows from 2 to 4 col 4
    cell_new.value = new_price        # assign the expression result to the new cell value


# now our first line to create Chart
# we begin by assigning the references of the cells we want to represent through
# this chart, such as sheetname, row and col start, row and col end to a variable called values or anything

values = Reference(sheet, min_row =2, max_row =sheet.max_row, min_col =4, max_col =4)



# create an object / instance of the class Barchart or LineChart

chart = BarChart3D()

# connect this instance to the references we wished for
chart.add_data(values)

# add this instance to our working sheet
sheet.add_chart(chart, 'e2')

wb.save('trans2.xlsx')









